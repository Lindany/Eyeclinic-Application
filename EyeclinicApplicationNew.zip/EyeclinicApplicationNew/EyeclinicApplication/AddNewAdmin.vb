﻿Public Class AddNewAdmin
    Private Sub ClearForm()
        boxUNameadm.Clear()
        boxPwdadm.Clear()
        boxadminfname.Clear()
        boxadminLastName.Clear()
        rdadmnM.Select()
        'dateadmDOB.Value.Day(0)
        boxPostaladm.Clear()
        boxadmPhyAdd.Clear()
        boxTeladm.Clear()
        boxEmailadm.Clear()
        boxnokadm.Clear()
        boxnokTel.Clear()
        boxReladm.Clear()
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click

        Dim gen As String 'New var to hold data from the radio button
        If rdadmF.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If

        Dim conf_var As Integer = StaffTableAdapter.InsertStaff(boxUNameadm.Text, boxPwdadm.Text, boxadminfname.Text, boxadminLastName.Text, gen, dateadmDOB.Value, boxPostaladm.Text, boxadmPhyAdd.Text, CDec(boxTeladm.Text), boxEmailadm.Text, boxnokadm.Text, boxnokTel.Text, boxReladm.Text)
        AdministratorTableAdapter.InsertAdmin(conf_var)
        AdministratorBindingSource.EndEdit()
        StaffBindingSource.EndEdit()
        StaffTableAdapter.Update(EyeclinicDataset.Staff)
        AdministratorTableAdapter.Update(EyeclinicDataset.Administrator)
        MessageBox.Show("Administrator " + boxadminfname.Text + " Inserted successfly", "Insertion Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub ToolStripButton1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton1.Click
        AdministratorBindingSource.EndEdit()
        StaffBindingSource.EndEdit()
        StaffTableAdapter.Update(EyeClinicDataset.Staff)
        AdministratorTableAdapter.Update(EyeClinicDataset.Administrator)
        MessageBox.Show("Update successfly", "Update Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub AddNewAdmin_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset3.Administrator' table. You can move, or remove it, as needed.
        Me.AdministratorTableAdapter3.Fill(Me.EyeclinicDataset3.Administrator)
        'TODO: This line of code loads data into the 'EyeclinicDataset3.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter3.Fill(Me.EyeclinicDataset3.Staff)
       
        
    End Sub

    Private Sub ToolStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked

    End Sub
End Class