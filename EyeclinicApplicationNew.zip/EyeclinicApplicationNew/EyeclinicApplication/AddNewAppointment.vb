﻿Public Class AddNewAppointment
    Public Function isAvailable() As Boolean
        SessionTableAdapter1.CheckAvailableSession(EyeclinicDataset1.Session, SelectSession.SelectedItem.ToString, dateDate.Value)
        If EyeclinicDataset1.Session.Rows.Count < 2 Then
            Return True
        Else
            Return False
        End If

    End Function

    Private Sub AddNewAppointment_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        AppointmentTableAdapter1.Fill(EyeclinicDataset1.Appointment)
        AdministratorTableAdapter1.Fill(EyeclinicDataset1.Administrator)
        TextBox1.Text = MainMenu.global_staffid
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click

        If SessionTableAdapter1.BookedSession(SelectSession.SelectedItem, dateDate.Value) > 5 Then

            MessageBox.Show("Selected Session is Fully Booked for selected Date !!!!")

        Else
            AppointmentTableAdapter1.AddApppoitment(dateDate.Value, StatusCombo.SelectedItem, boxappName.Text, boxsurname.Text, TextBox1.Text)
            BSAppointment.EndEdit()
            AppointmentTableAdapter1.Update(EyeclinicDataset1.Appointment)
            SessionTableAdapter1.AddSession(SelectSession.SelectedItem, EyeclinicDataset1.Appointment.Rows(BSAppointment.Count - 1)(0), dateDate.Value)
            AppointmentTableAdapter1.Fill(EyeclinicDataset1.Appointment)
            MessageBox.Show("Appointment successfully booked")
        End If
    End Sub

    Private Sub ToolStripButton2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton2.Click
        boxappName.Clear()
        boxsurname.Clear()
    End Sub

    Private Sub ToolStrip1_ItemClicked(sender As System.Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked
        ' Me.Close()
    End Sub

    Private Sub ToolStripButton4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub
End Class