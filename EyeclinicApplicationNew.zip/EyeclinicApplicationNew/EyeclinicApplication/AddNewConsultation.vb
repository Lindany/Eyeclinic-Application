﻿Public Class AddNewConsultation

    Private Sub AddNewConsultation_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ConsultationTableAdapter1.Fill(EyeclinicDataset1.Consultation)
        TextBox1.Text = MainMenu.global_studentNo
        AppointmentTableAdapter1.Fill(EyeclinicDataset1.Appointment)
    End Sub

    Private Sub ToolStripButton4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click

        ConsultationTableAdapter1.AddNew(TextBox1.Text, dateDate.Value, TextBox2.Text, TextBox3.Text)

        ConsultationTableAdapter1.Update(EyeclinicDataset1.Consultation)
        ConsultationTableAdapter1.Fill(EyeclinicDataset1.Consultation)
        MessageBox.Show("Patient consultation details successfully added!!!")

    End Sub


End Class