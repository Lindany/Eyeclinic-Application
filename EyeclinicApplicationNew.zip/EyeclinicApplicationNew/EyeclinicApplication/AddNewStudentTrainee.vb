﻿Public Class AddNewStudentTrainee

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        Dim gen As String 'New var to hold data from the radio button
        If RadioButton1.Checked Then
            gen = "F"
        Else
            gen = "M"
        End If

        TraineeStudentBindingSource.EndEdit()

        Dim staff_id As Integer = StaffTableAdapter.InsertStaff(TextBox1.Text, TextBox12.Text, TextBox2.Text, TextBox3.Text, gen, DateTimePicker1.Value, TextBox7.Text, TextBox4.Text, CDec(TextBox5.Text), TextBox6.Text, TextBox9.Text, CDec(TextBox10.Text), TextBox11.Text)
        TextBox8.Text = staff_id
        TraineeStudentTableAdapter.InsertStudentTrainee(TextBox13.Text, staff_id, ComboBox1.SelectedItem)

        TraineeStudentBindingSource.EndEdit()
        TraineeStudentTableAdapter.Update(EyeclinicDataset.TraineeStudent)
        'A.Update(EyeClinicDataset.Administrator)
        MessageBox.Show("TraneeiStudent  " + TextBox2.Text + " Inserted successfly", "Insertion Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub AddNewStudentTrainee_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset.TraineeStudent' table. You can move, or remove it, as needed.
        Me.TraineeStudentTableAdapter.Fill(Me.EyeclinicDataset.TraineeStudent)
        'TODO: This line of code loads data into the 'EyeclinicDataset.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.EyeclinicDataset.Staff)

    End Sub
End Class