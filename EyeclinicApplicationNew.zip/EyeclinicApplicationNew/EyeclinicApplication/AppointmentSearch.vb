﻿Public Class AppointmentSearch

    Private Sub AppointmentSearch_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        AppointmentTableAdapter1.Fill(EyeclinicDataset1.Appointment)
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        AppointmentTableAdapter1.searchByAppName(EyeclinicDataset1.Appointment, TextBox5.Text, TextBox6.Text)

    End Sub

    Private Sub ToolStripButton1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton1.Click
        BSAppointmentSearch.RemoveFilter()

        BSAppointmentSearch.EndEdit()
        AppointmentTableAdapter1.Update(EyeclinicDataset1.Appointment)
        AppointmentTableAdapter1.Fill(EyeclinicDataset1.Appointment)
        MessageBox.Show("Appoitment Changes successfully Added!!!")
    End Sub

    Private Sub ToolStripButton2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton2.Click
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
    End Sub

    Private Sub ToolStripButton4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub

    
End Class