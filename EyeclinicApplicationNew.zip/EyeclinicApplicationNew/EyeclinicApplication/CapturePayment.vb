﻿Public Class CapturePayment

    Private Sub Label6_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    
    Private Sub CapturePayment_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EyeclinicDataset1.Diagnosis' table. You can move, or remove it, as needed.
        Me.DiagnosisTableAdapter1.Fill(Me.EyeclinicDataset1.Diagnosis)
        'TODO: This line of code loads data into the 'EyeclinicDataset1.Patient' table. You can move, or remove it, as needed.
        Me.PatientTableAdapter1.Fill(Me.EyeclinicDataset1.Patient)
        Me.PaymentTableAdapter1.Fill(EyeclinicDataset1.Payment)

        TextBox5.Text = MainMenu.global_staffid
    End Sub

    Private Sub ToolStripButton4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub

    Private Sub ToolStripButton3_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripButton3.Click
        PatientTableAdapter1.UpdatePayement(TextBox1.Text, TextBox2.Text)
        BSPatient.EndEdit()
        PatientTableAdapter1.selectPatient(EyeclinicDataset1.Patient, TextBox2.Text)
        Dim Balance As Decimal = EyeclinicDataset1.Patient.Rows(0)("Balance")
        If Balance < 0 Then
            Balance = 0.0
        End If
        PatientTableAdapter1.Update(EyeclinicDataset1.Patient)
        PatientTableAdapter1.Fill(EyeclinicDataset1.Patient)
        MessageBox.Show("Payement Successfu Made Outstading Balence is Now: " & Balance.ToString("C"))

    End Sub
End Class