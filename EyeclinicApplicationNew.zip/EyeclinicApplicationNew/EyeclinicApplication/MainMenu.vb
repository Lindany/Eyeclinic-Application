﻿Public Class MainMenu

    Friend Shared global_username As String
    Friend Shared global_staffid As String
    Friend Shared global_staffType As String
    Friend Shared global_studentNo As String
    Public Sub FormSetUp(ByVal ChildForm As Form)
        Try
            If Not (ChildForm.Equals(Me.ActiveMdiChild)) Then
                Me.ActiveMdiChild.Close()
            End If
        Catch ex As Exception
        End Try
        With ChildForm
            .MdiParent = Me
            .WindowState = FormWindowState.Maximized
            .Show()
        End With
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem2.Click
        Login.Show()

    End Sub

    Private Sub ToolStripMenuItem8_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem8.Click
        ChangePassword.Show()
    End Sub

    Private Sub ToolStripMenuItem11_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem11.Click
        FormSetUp(AddNewAdmin)
    End Sub

    Private Sub ToolStripMenuItem13_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem13.Click
        FormSetUp(AddNewStudentTrainee)
    End Sub

    Private Sub ToolStripMenuItem4_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem4.Click
        FormSetUp(AddNewAppointment)
    End Sub

    Private Sub ToolStripMenuItem5_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem5.Click
        FormSetUp(AppointmentSearch)
    End Sub

    Private Sub ToolStripMenuItem6_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem6.Click
        FormSetUp(AddNewPatient)
    End Sub

    Private Sub CapturePaymentToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs)
        FormSetUp(CapturePayment)
    End Sub

    Private Sub ToolStripMenuItem16_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Label2.Text = Format(Now, "HH:mm:ss")
        Label3.Text = global_staffType
        Label4.Text = global_username
    End Sub

    Private Sub ToolStripMenuItem14_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem14.Click
        FormSetUp(AddNewConsultation)
    End Sub

    Private Sub ToolStripMenuItem15_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem15.Click
        FormSetUp(AddNewDiagnosis)
    End Sub

    Private Sub MainMenu_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ToolStripMenuItem7.Enabled = False
        ToolStripMenuItem3.Enabled = False
        Patient.Enabled = False
        ToolStripMenuItem16.Enabled = False

    End Sub

    Private Sub ToolStripMenuItem17_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripMenuItem17.Click
        FormSetUp(CapturePayment)

    End Sub

End Class
